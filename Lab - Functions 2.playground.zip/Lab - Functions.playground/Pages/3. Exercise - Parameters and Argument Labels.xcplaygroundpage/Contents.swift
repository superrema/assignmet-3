func introduction(name : String, home : String, age : Int){
    print("hi this is \(name) and am from \(home) and am \(age) years old")
}
introduction(name: "loly", home: "italy", age: 21)
//:  Write a function called `almostAddition` that takes two `Int` arguments. The first argument should not require an argument label. The function should add the two arguments together, subtract 2, then print the result. Call the function and observe the printout.
func almostAddition( _firstnumber : Int , secondnumber : Int) {
   print((_firstnumber + secondnumber))
    print((_firstnumber - secondnumber))
}
almostAddition(_firstnumber: 12, secondnumber: 4)
//:  Write a function called `multiply` that takes two `Double` arguments. The function should multiply the two arguments and print the result. The first argument should not require a label, and the second argument should have an external label, `by`, that differs from the internal label. Call the function and observe the printout.
func multiply(_firstnumber : Double , by secondnumber : Double){
    print((_firstnumber * secondnumber))
}
multiply(_firstnumber : 4.2, by: 2.2)
/*:
[Previous](@previous)  |  page 3 of 6  |  [Next: App Exercise - Progress Updates](@next)
 */
